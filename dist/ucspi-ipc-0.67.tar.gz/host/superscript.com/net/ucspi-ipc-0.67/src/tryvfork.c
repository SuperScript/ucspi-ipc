main()
{
  vfork();
}
