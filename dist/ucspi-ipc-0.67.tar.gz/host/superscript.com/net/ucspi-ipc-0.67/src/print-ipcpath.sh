pathlen="`./tryipcpath`"
echo '#ifndef IPCPATH_H'
echo '#define IPCPATH_H'
echo ''
echo "#define IPCPATH_MAX $pathlen"
echo ''
echo '#endif'
